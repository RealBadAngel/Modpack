minetest.register_node("pump:pump", {
	description = "Pump",
	tiles = {"default_wood.png"},
	groups = {snappy=2,choppy=2,oddly_breakable_by_hand=2},
	sounds = default.node_sound_wood_defaults(),

	on_construct = function(pos)
		local meta = minetest.env:get_meta(pos)
		end,	
})

minetest.register_abm({
	nodenames = {"pump:pump"},
	interval = 1,
	chance = 1,
	action = function(pos, node, active_object_count, active_object_count_wider)
	local meta = minetest.env:get_meta(pos)
		
	local pos1={}

	pos1.y=pos.y
	pos1.x=pos.x+1
	pos1.z=pos.z


	meta1 = minetest.env:get_meta(pos1)
	if meta1:get_int("pipelike")~=1 then return end

		local PIPE_nodes = {}
		local GRATE_nodes = {}
		local TANK_nodes = {}

	 	PIPE_nodes[1]={}
	 	PIPE_nodes[1].x=pos1.x
		PIPE_nodes[1].y=pos1.y
		PIPE_nodes[1].z=pos1.z


table_index=1
	repeat
	check_PIPE_node (PIPE_nodes,GRATE_nodes,TANK_nodes,table_index)
	table_index=table_index+1
	if PIPE_nodes[table_index]==nil then break end
	until false
found=table_index-1
print("Found "..found.." pipes connected")
end
})

function add_new_pipe_node (PIPE_nodes,pos1)
local i=1
	repeat
		if PIPE_nodes[i]==nil then break end
		if pos1.x==PIPE_nodes[i].x and pos1.y==PIPE_nodes[i].y and pos1.z==PIPE_nodes[i].z then return false end
		i=i+1
	until false
PIPE_nodes[i]={}
PIPE_nodes[i].x=pos1.x
PIPE_nodes[i].y=pos1.y
PIPE_nodes[i].z=pos1.z
return true
end

function check_PIPE_node (PIPE_nodes,GRATE_nodes,TANK_nodes,i)
		local pos1={}
		pos1.x=PIPE_nodes[i].x
		pos1.y=PIPE_nodes[i].y
		pos1.z=PIPE_nodes[i].z
		new_node_added=false
	
		pos1.x=pos1.x+1
		check_PIPE_node_subp (PIPE_nodes,GRATE_nodes,TANK_nodes,pos1)
		pos1.x=pos1.x-2
		check_PIPE_node_subp (PIPE_nodes,GRATE_nodes,TANK_nodes,pos1)
		pos1.x=pos1.x+1
		
		pos1.y=pos1.y+1
		check_PIPE_node_subp (PIPE_nodes,GRATE_nodes,TANK_nodes,pos1)
		pos1.y=pos1.y-2
		check_PIPE_node_subp (PIPE_nodes,GRATE_nodes,TANK_nodes,pos1)
		pos1.y=pos1.y+1

		pos1.z=pos1.z+1
		check_PIPE_node_subp (PIPE_nodes,GRATE_nodes,TANK_nodes,pos1)
		pos1.z=pos1.z-2
		check_PIPE_node_subp (PIPE_nodes,GRATE_nodes,TANK_nodes,pos1)
		pos1.z=pos1.z+1
return new_node_added
end

function check_PIPE_node_subp (PIPE_nodes,GRATE_nodes,TANK_nodes,pos1)
meta = minetest.env:get_meta(pos1)
if meta:get_float("pipelike")==1 then add_new_pipe_node(PIPE_nodes,pos1) end
end
		

