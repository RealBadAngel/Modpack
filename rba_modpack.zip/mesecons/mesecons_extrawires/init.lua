dofile(minetest.get_modpath("mesecons_extrawires").."/crossing.lua");
dofile(minetest.get_modpath("mesecons_extrawires").."/tjunction.lua");
