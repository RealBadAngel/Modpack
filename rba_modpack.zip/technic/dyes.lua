minetest.register_craft({
	type = "cooking",
	output = "dye:black 2",
	recipe = "default:coal_lump",
})
minetest.register_craft({
	type = "cooking",
	output = "dye:green 2",
	recipe = "default:cactus",
})
minetest.register_craft({
	type = "cooking",
	output = "dye:red 2",
	recipe = "flowers:flower_rose",
})
minetest.register_craft({
	type = "cooking",
	output = "dye:blue 2",
	recipe = "flowers:flower_viola",
})
minetest.register_craft({
	type = "cooking",
	output = "dye:white 2",
	recipe = "flowers:flower_dandelion_white",
})
minetest.register_craft({
	type = "cooking",
	output = "dye:yellow 2",
	recipe = "flowers:flower_dandelion_yellow",
})
minetest.register_craft({
	type = "cooking",
	output = "dye:orange 2",
	recipe = "flowers:flower_tulip",
})
minetest.register_craft({
	type = "cooking",
	output = "dye:brown 2",
	recipe = "default:dry_shrub",
})